# Changelog

All notable development work for this student project is recorded here.

## [1.0.0] — 2026-10-05

### Added

- Two complete website project proposals.
- Detailed desktop and mobile wireframes.
- Technical requirements, delivery timeline, and itemised project budget.
- Comprehensive references and image-use notes.
- Submission guide, page-content summaries, and a fuller website README.
- High-level explanatory comments in the HTML, CSS, and JavaScript source files.

### Verified

- The submission folder includes the complete static website, local image assets, planning documents, and source record.
- The website can run locally by opening `site/index.html` or by serving the `site` folder through a local static server.

## [0.3.0] — 2026-08-24

### Changed

- Organised the submission into separate `site`, `images`, `documents`, `texts`, and `resources` folders.

## [0.2.0] — 2026-08-19

### Changed

- Added supplied Gift of the Givers logo, volunteer, and food-parcel images.
- Introduced a forest-green, gold, cream, and black humanitarian-action theme.
- Applied supplied imagery to the logo treatment, home-page hero, and programme cards.

## [0.1.0] — 2026-08-15

### Added

- Initial six-page static website: Home, About, Our Work, Impact, Get Involved, and Contact.
- Shared responsive stylesheet and JavaScript for mobile navigation and a demonstration form.

### Changed

- Improved typography, spacing, cards, buttons, keyboard focus states, and responsive behaviour.
