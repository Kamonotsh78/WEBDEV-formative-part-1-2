# Gift of the Givers — Student Website Project

**Student:** Kamogelo Notshweleka  
**Student number:** ST10527251  
**Module:** WEBDEV  

## Overview

This is a responsive, six-page informational website concept about the Gift of the Givers Foundation. It is an academic project intended to demonstrate research, content structure, visual design, HTML, CSS, JavaScript, and responsive web development. It is not an official Gift of the Givers website.

## Features

- Six linked pages: Home, About, Our Work, Impact, Get Involved, and Contact.
- Consistent desktop and mobile navigation.
- Humanitarian-action visual theme using forest green, gold, cream, and black.
- Local logo, volunteer, and food-parcel images.
- Responsive CSS Grid and Flexbox layouts.
- Keyboard-focus styles and reduced-motion support.
- Front-end-only contact-form demonstration; no form data is sent or stored.

## Run the website

### Option 1: Open directly

Open `index.html` in a modern web browser.

### Option 2: Use a local server

Open this project folder in Visual Studio Code, then use a static-server extension or another local server. Open the local address in a browser. A local server is recommended when checking asset paths and browser behaviour.

## Project structure

```text
gift-of-the-givers-submission/
├── index.html                 # Home page
├── about.html                 # Organisation background and timeline
├── our-work.html              # Programme areas
├── impact.html                # Selected reported statistics
├── get-involved.html          # Official routes for supporters
├── contact.html               # Contact information and demo form
├── css/style.css              # Shared visual and responsive styles
├── js/script.js               # Mobile menu and demo-form behaviour
└── images/                    # Local image assets
```

## Technology used

- HTML5 for page structure and content.
- CSS3 for variables, layout, typography, responsive breakpoints, animations, and focus states.
- Vanilla JavaScript for the collapsible mobile navigation and demonstration contact form.
- Google Fonts: DM Sans and Space Grotesk.

## Accessibility and responsive design

- Pages include descriptive document titles and viewport settings.
- Links, buttons, and form fields have visible keyboard-focus styles.
- The mobile navigation uses `aria-expanded` to communicate its open state.
- CSS adapts multi-column content to smaller tablet and mobile layouts.
- A reduced-motion media query reduces transitions for users who request it.

## Content and research note

Organisation information, programme descriptions, selected impact figures, and contact details are based on official Gift of the Givers pages. These facts may change and must be verified before final academic submission. The project intentionally directs real donations and enquiries to official channels.

## Image-use note

The project uses supplied Gift of the Givers image assets. Permission, copyright ownership, source URL, and access date must be recorded in the submission asset log before final submission. Do not assume official-website images are free to reuse.

## Known limitations

- The contact form is a visual front-end demonstration only; it has no backend or email connection.
- Statistics and contact information can become outdated.
- This project does not include payment processing, user accounts, a database, analytics, or a content-management system.

## Testing checklist

- Test each navigation link on desktop and mobile widths.
- Open and close the mobile navigation with pointer and keyboard input.
- Check that all images load from `images/`.
- Submit the demo form and confirm the feedback message appears.
- Inspect content at 320 px, tablet, and desktop widths.
- Check headings, focus indicators, labels, external links, spelling, and contrast.

## Supporting documents

The project root includes two complete proposals in `proposals/`; wireframes, technical requirements, a timeline, and a budget in `planning/`; plus research notes, references, and an asset log in `research/`.

## References

See `research/references.md` for the project reference list and `research/asset-log.csv` for asset documentation.
