// The menu button is shown on smaller screens; this keeps the existing navigation usable on mobile.
const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');

if (menuButton && nav) {
  menuButton.addEventListener('click', () => {
    // Toggle the display class and communicate the same state to assistive technology.
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
  });
}

// This form is intentionally a front-end demonstration: it does not send or store visitor data.
const contactForm = document.querySelector('#contactForm');
const formMessage = document.querySelector('#formMessage');

if (contactForm && formMessage) {
  contactForm.addEventListener('submit', (event) => {
    // Keep the visitor on the page and show a clear message about the prototype limitation.
    event.preventDefault();
    formMessage.textContent = 'Demo submitted. Connect this form to a backend/email service in a later project phase.';
    contactForm.reset();
  });
}
