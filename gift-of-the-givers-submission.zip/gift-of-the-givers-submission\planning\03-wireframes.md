# Wireframes

These low-fidelity wireframes document the intended layout before visual styling. `[]` indicates a content area; arrows show primary actions. The same header and footer are used across all pages.

## Desktop: Home page

```text
+--------------------------------------------------------------------------------+
| [Logo] Gift of the Givers       Home About Our Work Impact Get Involved Contact |
+--------------------------------------------------------------------------------+
| EYEBROW                                                                       |
| Serving Humanity.                         [Volunteer photograph]              |
| Supporting introduction                    [Hope information card]             |
| [Explore our work]  [View impact]                                         |
+--------------------------------------------------------------------------------+
| OUR PRIMARY FOCUS                                                               |
| Where help becomes action.                                                      |
| [01 Disaster] [02 Hunger] [03 Water]                                           |
| [04 Healthcare] [05 Education] [06 Human Development]                          |
+--------------------------------------------------------------------------------+
| [1992 Founded] [47 Countries] [R6B Aid] [120K+ Food parcels]                  |
+--------------------------------------------------------------------------------+
| WHY IT MATTERS                         Supporting copy and [Learn more ->]    |
+--------------------------------------------------------------------------------+
| Yellow call-to-action panel                               [Get involved]       |
+--------------------------------------------------------------------------------+
| Footer: project identification | research note | contact link                  |
+--------------------------------------------------------------------------------+
```

## Desktop: Inner content page (About, Our Work, Impact, or Get Involved)

```text
+--------------------------------------------------------------------------------+
| Shared header and navigation                                                    |
+--------------------------------------------------------------------------------+
| PAGE EYEBROW                                                                    |
| Large page title                                                                |
| One-sentence introduction                                                       |
+--------------------------------------------------------------------------------+
| [Section heading / explanatory text]                                            |
| [Cards, timeline, statistics, or two-column content]                           |
| [Cards, timeline, statistics, or two-column content]                           |
+--------------------------------------------------------------------------------+
| Yellow call-to-action panel with one clear button                               |
+--------------------------------------------------------------------------------+
| Shared footer                                                                   |
+--------------------------------------------------------------------------------+
```

## Desktop: Contact page

```text
+--------------------------------------------------------------------------------+
| Shared header                                                                    |
+--------------------------------------------------------------------------------+
| CONTACT / Connect with the organisation                                         |
+-----------------------------------+--------------------------------------------+
| Official contact information       | Demonstration contact form                 |
| - Call centre                      | Name    [____________________]             |
| - Email                            | Email   [____________________]             |
| - Address                          | Subject [____________________]             |
| [Official contact link ->]         | Message [____________________]             |
|                                    |         [____________________]             |
|                                    | [Send demo message]                        |
+-----------------------------------+--------------------------------------------+
| Shared footer                                                                   |
+--------------------------------------------------------------------------------+
```

## Mobile: Home page and navigation

```text
+----------------------------------+
| [Logo] Gift of the Givers    [☰] |
+----------------------------------+
| When opened:                     |
| Home                              |
| About                             |
| Our Work                          |
| Impact                            |
| Get Involved                      |
| Contact                           |
+----------------------------------+
| EYEBROW                           |
| Serving Humanity.                 |
| Supporting introduction           |
| [Explore our work]                |
| [View impact]                     |
| [Volunteer image]                 |
| [Hope information card]           |
+----------------------------------+
| Focus card 01                     |
| Focus card 02                     |
| ... one card per row              |
+----------------------------------+
| One impact item per row           |
+----------------------------------+
| Full-width call-to-action button  |
+----------------------------------+
```

## Interaction notes

- On screens below 900 px, the navigation changes into a menu button; it expands and collapses the existing navigation list.
- Buttons and links use visible hover and keyboard-focus states.
- Card grids progressively change from three columns to two columns and then one column.
- The contact form is a front-end demonstration. It does not transmit data.
