# Technical Requirements

## Technology

| Area | Requirement | Reason |
| --- | --- | --- |
| Markup | HTML5 with semantic `header`, `nav`, `main`, `section`, `article`, `footer`, and `form` elements | Gives content meaningful structure |
| Styling | One shared CSS file with custom properties, Flexbox, Grid, media queries, and focus styles | Keeps the design consistent and responsive |
| Interaction | Vanilla JavaScript only | Controls the mobile navigation and demo-form feedback without unnecessary frameworks |
| Assets | Local JPG, JPEG, PNG, and SVG files | Prevents broken external image links and supports offline marking |
| Fonts | DM Sans and Space Grotesk from Google Fonts, with system-font fallback | Gives clear, modern typography |
| Hosting | Static-file hosting or local web server | No database, server code, account system, or payment handling is required |

## Browser and device support

- Current versions of Chrome, Microsoft Edge, Firefox, and Safari.
- Responsive layouts tested at approximately 320 px, 560 px, 900 px, and desktop widths.
- Touch-friendly buttons with a minimum visual height of about 48 px.

## Functional requirements

- Every top navigation item opens its corresponding HTML page.
- The current page is visually identified in the navigation.
- The mobile menu opens and updates `aria-expanded` when activated.
- Primary calls to action link to an appropriate internal page or official external page.
- The demonstration contact form prevents actual submission, shows a confirmation message, and clears only after the message is set.
- External links that open in new tabs use `rel="noopener"`.

## Accessibility requirements

- Use a single meaningful `h1` per page and ordered heading levels below it.
- Provide visible keyboard focus for links, buttons, and form fields.
- Maintain readable text contrast against cream, green, gold, and black backgrounds.
- Use descriptive links rather than ambiguous labels such as “click here.”
- Include `aria-label` or other accessible names where visual labels are insufficient.
- Respect users who request reduced motion with the `prefers-reduced-motion` media query.

## Quality checks before submission

1. Open `site/index.html` and test every navigation link.
2. Test the menu at mobile width and with keyboard Tab/Enter keys.
3. Check that all local image paths load.
4. Check headings, alt text, labels, and visible focus states.
5. Check the form message; do not treat it as a real contact form.
6. Recheck all official facts, contact details, image permissions, and statistics.
