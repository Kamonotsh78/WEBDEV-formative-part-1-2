# Project Timeline

The timeline below is a realistic four-week plan for a small static website project. Dates can be adjusted to match the module schedule.

| Week | Activities | Output / checkpoint |
| --- | --- | --- |
| 1: Research and planning | Research official organisation information; identify target users; define pages; collect permitted assets; create design direction and wireframes | Two project proposals, research notes, wireframes, asset log started |
| 2: Content and visual design | Write concise page copy; define colour, typography, card, and button system; prepare image assets; confirm responsive layout plan | Approved content outline and design system |
| 3: Build | Create semantic HTML pages; add shared CSS; implement navigation, responsive grids, imagery, and demo form behaviour | Functional desktop and mobile website prototype |
| 4: Test and submit | Test links, menu, form feedback, mobile layout, accessibility basics, spelling, references, README, and file organisation | Final submission folder, changelog, references, and project documentation |

## Milestones

- **M1 — Scope approved:** pages, audience, and visual direction agreed.
- **M2 — Wireframes complete:** desktop and mobile layouts documented before final styling.
- **M3 — Build complete:** all pages, images, links, and responsive behaviour working.
- **M4 — Quality check complete:** no known broken links or missing submission documents.

## Dependencies and contingency

- Content facts and contact details depend on official-source verification.
- Image use depends on recorded permission or an appropriate licence.
- Reserve at least one day in Week 4 for correcting responsive or accessibility problems found during testing.
