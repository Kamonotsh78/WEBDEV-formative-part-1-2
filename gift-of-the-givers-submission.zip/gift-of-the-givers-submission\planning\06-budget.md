# Project Budget

This is a planning estimate in South African rand (ZAR) for a small static website. The student-development time is included to demonstrate the full project value; using a free academic hosting option would reduce the cash cost.

| Item | Assumption | Estimated cost (ZAR) |
| --- | --- | ---: |
| Project planning and research | 6 hours at R150/hour | R900 |
| Content writing and editing | 8 hours at R150/hour | R1,200 |
| Wireframes and visual design | 8 hours at R180/hour | R1,440 |
| HTML/CSS/JavaScript development | 20 hours at R180/hour | R3,600 |
| Responsive and accessibility testing | 5 hours at R150/hour | R750 |
| Image preparation and asset-log administration | 2 hours at R150/hour | R300 |
| Domain name (one year, optional) | `.co.za` or equivalent estimate | R150 |
| Static hosting (one year, optional) | Entry-level hosting estimate | R600 |
| Image licence / permission contingency | Only if written permission or free licence is not available | R1,000 |
| **Estimated total** |  | **R9,940** |

## Cost controls

- Use free educational tools and static hosting where permitted.
- Use only images with documented permission or an appropriate licence.
- Avoid paid frameworks, databases, and payment integrations in the student prototype.
- Keep the site static; this reduces hosting, maintenance, security, and privacy costs.

## Budget assumptions

This is an estimate, not an invoice. Costs for image permissions, domain names, and hosting vary by supplier. If the website is submitted only as local files, the optional domain and hosting costs are not required, reducing the expected cash cost to **R9,190** before any image-licence charge.
