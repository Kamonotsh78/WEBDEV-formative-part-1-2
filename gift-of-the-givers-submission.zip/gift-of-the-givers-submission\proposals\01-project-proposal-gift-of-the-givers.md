# Website Project Proposal 1: Gift of the Givers Information Website

**Student:** Kamogelo Notshweleka  
**Student number:** ST10527251  
**Module:** WEBDEV  
**Project type:** Responsive informational website

## 1. Project overview

This project is a responsive, multi-page informational website about the Gift of the Givers Foundation. Its purpose is to help visitors understand the organisation's humanitarian work, reported impact, and official ways to get involved. The website is an educational student project: it does not accept donations, store personal information, or claim to be the official organisation website.

## 2. Problem and opportunity

Humanitarian organisations communicate complex work across many programmes, countries, and audiences. A visitor should be able to quickly understand the organisation's purpose, discover its focus areas, review selected impact information, and find official contact or donation channels. The opportunity is to demonstrate a clear, trustworthy, mobile-friendly user experience for this information.

## 3. Goal and objectives

**Goal:** Create a professional, accessible, and responsive website concept that communicates humanitarian action with clarity and dignity.

**Objectives:**

- Present the organisation's purpose and six focus areas in plain language.
- Make the six-page navigation easy to use on desktop and mobile.
- Use strong visual hierarchy, supplied organisation imagery, and a coherent green, gold, cream, and black theme.
- Clearly label organisation-reported statistics and direct real enquiries or donations to official channels.
- Build the project with semantic HTML, reusable CSS, and small amounts of JavaScript only where interaction is needed.

## 4. Target audience

| Audience | Need | Website response |
| --- | --- | --- |
| General public | Quick understanding of the organisation | Hero message, About page, clear navigation |
| Potential donors/supporters | Trustworthy route to official action | Get Involved page links only to official channels |
| Students and researchers | A concise summary of programmes and impact | Our Work, Impact, and cited research material |
| Corporate partners | A route to partnership information | Partner call to action and official partner link |
| Mobile visitors | Readable, touch-friendly experience | Collapsible navigation and single-column mobile layouts |

## 5. Content and information architecture

The website has six pages:

1. **Home** — mission statement, focus areas, selected impact figures, and calls to action.
2. **About** — background, philosophy, and a short timeline.
3. **Our Work** — disaster response, hunger alleviation, water provision, healthcare, education, and human development.
4. **Impact** — selected organisation-reported figures with a verification reminder.
5. **Get Involved** — safe routes to official donation, partnership, and information pages.
6. **Contact** — verified contact details and a clearly labelled demonstration form.

## 6. Design aesthetic

The visual direction is **humanitarian action with dignity**. Forest green is used as a calm supporting brand colour, gold represents action and hope, cream creates warm reading space, and black provides contrast. Supplied photos of volunteers and food-parcel distribution make the design feel grounded in people and service rather than abstract decoration. Rounded cards, generous whitespace, strong headings, and clear buttons support a modern, professional presentation.

## 7. Functional and technical requirements

- Semantic HTML5 pages linked through a consistent navigation menu.
- One shared CSS stylesheet for visual consistency and responsive layout.
- A small JavaScript file for the mobile menu and the front-end-only contact-form message.
- Working internal page links and official external links opened safely in a new tab.
- Responsive layouts for desktop, tablet, and mobile screens.
- Keyboard-visible focus states, useful image alternatives where images carry meaning, and readable colour contrast.
- No framework, database, account system, payment processing, or real form submission in this phase.

## 8. Deliverables

- Complete static website in `site/`.
- Image assets in `images/` and `site/images/`.
- Wireframes, technical requirements, timeline, budget, references, and changelog in this submission folder.
- A detailed README explaining how to run and review the project.

## 9. Success criteria

- Every navigation link works and marks the current page.
- A visitor can identify the mission and primary actions within the first screen.
- The layout remains readable at 320 px, tablet, and desktop widths.
- The contact form prevents the default submission and clearly explains that it is a demonstration.
- All research claims are traceable to listed official sources and are described as organisation-reported where appropriate.

## 10. Constraints and risk controls

- Official statistics and contact details can change; they must be checked again immediately before submission.
- Organisation images may require permission; the asset log must record source, ownership, licence/permission, and access date.
- The form is intentionally non-functional to avoid collecting user data in a student project.
- Real donation details are not reproduced; users are sent to official pages instead.

## 11. Project plan and cost

See `documents/03-timeline.md` for the staged schedule and `documents/04-budget.md` for the estimated budget.

## 12. Key sources

Gift of the Givers Foundation. (n.d.). *Gift of the Givers Foundation*. Retrieved October 4, 2026, from https://giftofthegivers.org/  
Gift of the Givers Foundation. (n.d.). *About us*. Retrieved October 4, 2026, from https://giftofthegivers.org/about-us-3/  
Gift of the Givers Foundation. (n.d.). *What we do*. Retrieved October 4, 2026, from https://giftofthegivers.org/about-us-3/what-we-do/
