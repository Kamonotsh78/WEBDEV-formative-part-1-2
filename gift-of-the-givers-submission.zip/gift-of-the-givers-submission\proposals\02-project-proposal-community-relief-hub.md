# Website Project Proposal 2: Community Relief Hub

**Student:** Kamogelo Notshweleka  
**Student number:** ST10527251  
**Module:** WEBDEV  
**Project type:** Responsive community-resource website concept

## 1. Project overview

Community Relief Hub is an alternative website proposal for a local community organisation that coordinates food, water, clothing, and emergency-support information. Unlike the Gift of the Givers concept, this project would focus on a single local community and would publish verified resources, collection points, and volunteer opportunities.

## 2. Problem and opportunity

During a local emergency, people may not know where to request help, donate useful items, or find verified support. Information is often scattered across social media posts. The proposed hub would make trusted local information easier to find from a mobile phone.

## 3. Goal and objectives

**Goal:** Design a simple, mobile-first community information hub that connects people to verified relief resources.

**Objectives:**

- Publish emergency notices and support categories in a scannable format.
- Show verified collection points, operating hours, and contact options.
- Explain what items are needed and what should not be donated.
- Give volunteers a clear, safe route to register interest.
- Use accessible typography, high contrast, and low-data images.

## 4. Target audience

| Audience | Need | Proposed response |
| --- | --- | --- |
| Residents needing help | Immediate, verified support information | Emergency banner and support directory |
| Donors | A practical list of needed items | Donation checklist and collection locations |
| Volunteers | Clear participation instructions | Volunteer-interest form and shift information |
| Local partners | A way to coordinate with the project | Partner contact and update area |

## 5. Proposed pages

1. **Home** — urgent notices, key actions, and current needs.
2. **Find Help** — food, water, shelter, health, and referral information.
3. **Donate Items** — accepted items, collection points, and safety rules.
4. **Volunteer** — role descriptions, requirements, and interest form.
5. **Updates** — dated notices so information is clearly current or expired.
6. **Contact** — verified phone, email, and emergency-disclaimer information.

## 6. Design aesthetic

The interface would use a calm navy, teal, warm off-white, and orange alert palette. Large status labels, simple icons, short paragraphs, and prominent date stamps would help users make decisions quickly. The tone would be practical, respectful, and non-sensational.

## 7. Functional and technical requirements

- Static HTML/CSS/JavaScript prototype with no framework.
- Mobile-first responsive grid and keyboard-accessible navigation.
- Content cards that include a title, location, date, and status label.
- Clearly labelled external emergency and partner links.
- Form validation for a future volunteer-interest form; no production data collection in the prototype.
- Image alternatives, headings in logical order, visible focus styles, and WCAG-aware colour contrast.

## 8. Proposed schedule and budget

The same four-week planning and build approach in `03-timeline.md` would apply. A more complete version would budget for content verification, a domain, hosting, image permission, and ongoing monthly updates. See `04-budget.md` for the sample cost model.

## 9. Success criteria

- A user can find an urgent contact, collection point, or support category in fewer than three interactions.
- Every update shows an issue date and status.
- The site works on a 320 px mobile screen and with keyboard navigation.
- No donation claim, emergency notice, or contact detail is published without verification.

## 10. Risks and controls

- **Outdated emergency information:** add dates, expiry labels, and an assigned content reviewer.
- **Unverified donation requests:** publish only approved channels and report suspicious requests.
- **Accessibility barriers:** test contrast, headings, keyboard operation, and mobile layout before release.
- **Privacy:** do not collect personal details until a privacy notice and secure form process are in place.
