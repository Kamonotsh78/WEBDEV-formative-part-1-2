# Image asset notes

The website uses these supplied assets:

- `gotg-logo.png` — Gift of the Givers logo.
- `gotg-volunteers.jpg` — volunteer image used in the website hero and programme card.
- `gotg-food-parcels.jpeg` — food-parcel image used in a programme card.

Complete `asset-log-template.csv` with source, creator, licence or permission, and access date before submitting. Do not assume that an image from an organisation website may be reused without permission.
