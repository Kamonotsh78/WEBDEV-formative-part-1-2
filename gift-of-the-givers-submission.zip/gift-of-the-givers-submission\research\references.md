# References

The following references use an APA-style format. All organisation figures, programme summaries, and contact details in the student website should be checked against these official sources immediately before final submission.

Gift of the Givers Foundation. (n.d.-a). *About us*. Retrieved October 4, 2026, from https://giftofthegivers.org/about-us-3/

Gift of the Givers Foundation. (n.d.-b). *Contact us*. Retrieved October 4, 2026, from https://giftofthegivers.org/contact-us-4/

Gift of the Givers Foundation. (n.d.-c). *Gift of the Givers Foundation*. Retrieved October 4, 2026, from https://giftofthegivers.org/

Gift of the Givers Foundation. (n.d.-d). *Make a difference*. Retrieved October 4, 2026, from https://giftofthegivers.org/make-a-difference/

Gift of the Givers Foundation. (n.d.-e). *Partners*. Retrieved October 4, 2026, from https://giftofthegivers.org/partners/

Gift of the Givers Foundation. (n.d.-f). *What we do*. Retrieved October 4, 2026, from https://giftofthegivers.org/about-us-3/what-we-do/

MDN Web Docs. (n.d.). *HTML: HyperText Markup Language*. Retrieved October 4, 2026, from https://developer.mozilla.org/en-US/docs/Web/HTML

World Wide Web Consortium. (2023, October 5). *Web Content Accessibility Guidelines (WCAG) 2.2*. https://www.w3.org/TR/WCAG22/

## Image attribution and permission note

The following supplied image files are used in the website: `gotg-logo.png`, `gotg-volunteers.jpg`, and `gotg-food-parcels.jpeg`. Before final submission, record the original source URL, creator/copyright holder, licence or written permission, and access date in `asset-log-template.csv`. Do not assume that an image found on an organisation website is free to reuse.
