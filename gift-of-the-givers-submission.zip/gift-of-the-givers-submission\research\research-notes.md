# Gift of the Givers — Part 1 Research Notes

## Organisation
Gift of the Givers Foundation.

## Background
Gift of the Givers states that it was established in 1992 by Dr Imtiaz Sooliman. The organisation describes itself as the largest disaster-response NGO of African origin on the African continent.

## Purpose
The organisation's stated purpose is humanitarian: serving people in need, restoring hope and dignity, and providing assistance without discrimination.

## Main areas of work
1. Disaster Response
2. Hunger Alleviation
3. Water Provision
4. Healthcare
5. Education
6. Human Development

## Target audience for this student website
Primary:
- General public
- Potential supporters/donors
- People interested in humanitarian work

Secondary:
- Corporate partners
- Volunteers
- Researchers
- Journalists
- Students
- Communities seeking information

## Website objectives
1. Inform visitors about the organisation.
2. Explain the organisation's main programmes.
3. Present selected impact information clearly.
4. Direct users toward official ways to get involved.
5. Build trust through accurate information, clear navigation and source references.

## Success indicators
- Users can reach every main page through navigation.
- Users can understand the organisation's purpose quickly.
- Important programme information is easy to find.
- Statistics are clearly labelled and sourced.
- The website is responsive on desktop and mobile.
- Calls-to-action are visible.
- Contact information is easy to locate.
- Images and other assets are legally sourced.

## Resources needed
- Visual Studio Code or another code editor
- Web browser
- HTML
- CSS
- JavaScript
- Image-editing/compression tool
- Legally usable images
- Official organisation research
- Git/GitHub if repository submission is required

## Official research sources
- https://giftofthegivers.org/about-us-3/
- https://giftofthegivers.org/about-us-3/what-we-do/
- https://giftofthegivers.org/where-we-work/south-africa/
- https://giftofthegivers.org/
- https://giftofthegivers.org/contact-us-4/
- https://giftofthegivers.org/partners/
- https://giftofthegivers.org/make-a-difference/

## Important copyright note
The official Gift of the Givers website states that website content may not be copied or distributed for marketing and other purposes without consent. For this academic project, do not assume that official-site photographs are free to reuse. Either obtain permission or use images whose licences explicitly allow your intended use, and record the source, creator, licence and access date in an asset log.

## Figures used in the starter website
The starter website uses figures reported on the organisation's current official website, including 47 countries, R6 billion in aid, 120,000+ food parcels per year, 25,000+ stationery packs per year, 15,000+ patients monthly and 3 million+ litres of water per month. Re-check these figures before final submission because organisational figures can change.
